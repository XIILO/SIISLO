﻿namespace QLKT
{
    partial class hopdong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.mahopdong = new System.Windows.Forms.TextBox();
            this.cancuocongdan = new System.Windows.Forms.TextBox();
            this.hovaten = new System.Windows.Forms.TextBox();
            this.sodienthoai = new System.Windows.Forms.TextBox();
            this.sophong = new System.Windows.Forms.TextBox();
            this.sotiencoc = new System.Windows.Forms.TextBox();
            this.butload = new System.Windows.Forms.Button();
            this.butxoa = new System.Windows.Forms.Button();
            this.butsua = new System.Windows.Forms.Button();
            this.butthem = new System.Windows.Forms.Button();
            this.datagridviewhopdong = new System.Windows.Forms.DataGridView();
            this.butundo = new System.Windows.Forms.Button();
            this.butredo = new System.Windows.Forms.Button();
            this.ngayketthuc = new System.Windows.Forms.DateTimePicker();
            this.ngaybatdau = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hợpĐồngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngTiềnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hiểnThịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đãChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chưaChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngQuátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ngườiĐangThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewhopdong)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(70, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 44;
            this.label7.Text = "Ngày bắt đầu";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 176);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 43;
            this.label9.Text = "Tiền cọc";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(70, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 42;
            this.label10.Text = "Số phòng";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(70, 124);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 41;
            this.label11.Text = "Số điện thoại";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(70, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 40;
            this.label12.Text = "Họ và Tên";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(70, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 13);
            this.label13.TabIndex = 39;
            this.label13.Text = "CCCD";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(70, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 13);
            this.label14.TabIndex = 38;
            this.label14.Text = "Mã hợp đồng";
            // 
            // mahopdong
            // 
            this.mahopdong.Location = new System.Drawing.Point(159, 39);
            this.mahopdong.Name = "mahopdong";
            this.mahopdong.Size = new System.Drawing.Size(198, 20);
            this.mahopdong.TabIndex = 36;
            // 
            // cancuocongdan
            // 
            this.cancuocongdan.Location = new System.Drawing.Point(159, 65);
            this.cancuocongdan.Name = "cancuocongdan";
            this.cancuocongdan.Size = new System.Drawing.Size(198, 20);
            this.cancuocongdan.TabIndex = 35;
            // 
            // hovaten
            // 
            this.hovaten.Location = new System.Drawing.Point(159, 91);
            this.hovaten.Name = "hovaten";
            this.hovaten.Size = new System.Drawing.Size(198, 20);
            this.hovaten.TabIndex = 34;
            // 
            // sodienthoai
            // 
            this.sodienthoai.Location = new System.Drawing.Point(159, 117);
            this.sodienthoai.Name = "sodienthoai";
            this.sodienthoai.Size = new System.Drawing.Size(198, 20);
            this.sodienthoai.TabIndex = 33;
            // 
            // sophong
            // 
            this.sophong.Location = new System.Drawing.Point(159, 143);
            this.sophong.Name = "sophong";
            this.sophong.Size = new System.Drawing.Size(198, 20);
            this.sophong.TabIndex = 32;
            // 
            // sotiencoc
            // 
            this.sotiencoc.Location = new System.Drawing.Point(159, 169);
            this.sotiencoc.Name = "sotiencoc";
            this.sotiencoc.Size = new System.Drawing.Size(198, 20);
            this.sotiencoc.TabIndex = 31;
            // 
            // butload
            // 
            this.butload.AutoSize = true;
            this.butload.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.butload.Location = new System.Drawing.Point(692, 180);
            this.butload.Name = "butload";
            this.butload.Size = new System.Drawing.Size(96, 60);
            this.butload.TabIndex = 29;
            this.butload.Text = "Reload";
            this.butload.UseVisualStyleBackColor = false;
            this.butload.Click += new System.EventHandler(this.butload_Click);
            // 
            // butxoa
            // 
            this.butxoa.Location = new System.Drawing.Point(488, 503);
            this.butxoa.Name = "butxoa";
            this.butxoa.Size = new System.Drawing.Size(96, 60);
            this.butxoa.TabIndex = 28;
            this.butxoa.Text = "Delete";
            this.butxoa.UseVisualStyleBackColor = true;
            this.butxoa.Click += new System.EventHandler(this.butxoa_Click);
            // 
            // butsua
            // 
            this.butsua.Location = new System.Drawing.Point(590, 503);
            this.butsua.Name = "butsua";
            this.butsua.Size = new System.Drawing.Size(96, 60);
            this.butsua.TabIndex = 27;
            this.butsua.Text = "Alter";
            this.butsua.UseVisualStyleBackColor = true;
            this.butsua.Click += new System.EventHandler(this.butsua_Click);
            // 
            // butthem
            // 
            this.butthem.Location = new System.Drawing.Point(692, 503);
            this.butthem.Name = "butthem";
            this.butthem.Size = new System.Drawing.Size(96, 60);
            this.butthem.TabIndex = 30;
            this.butthem.Text = "Add";
            this.butthem.UseVisualStyleBackColor = true;
            this.butthem.Click += new System.EventHandler(this.butthem_Click);
            // 
            // datagridviewhopdong
            // 
            this.datagridviewhopdong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewhopdong.Location = new System.Drawing.Point(12, 254);
            this.datagridviewhopdong.Name = "datagridviewhopdong";
            this.datagridviewhopdong.Size = new System.Drawing.Size(776, 224);
            this.datagridviewhopdong.TabIndex = 26;
            this.datagridviewhopdong.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridviewhopdong_CellContentClick);
            // 
            // butundo
            // 
            this.butundo.Location = new System.Drawing.Point(159, 503);
            this.butundo.Name = "butundo";
            this.butundo.Size = new System.Drawing.Size(96, 60);
            this.butundo.TabIndex = 29;
            this.butundo.Text = "Undo";
            this.butundo.UseVisualStyleBackColor = true;
            // 
            // butredo
            // 
            this.butredo.Location = new System.Drawing.Point(261, 503);
            this.butredo.Name = "butredo";
            this.butredo.Size = new System.Drawing.Size(96, 60);
            this.butredo.TabIndex = 29;
            this.butredo.Text = "Redo";
            this.butredo.UseVisualStyleBackColor = true;
            // 
            // ngayketthuc
            // 
            this.ngayketthuc.Location = new System.Drawing.Point(159, 220);
            this.ngayketthuc.Name = "ngayketthuc";
            this.ngayketthuc.Size = new System.Drawing.Size(198, 20);
            this.ngayketthuc.TabIndex = 45;
            // 
            // ngaybatdau
            // 
            this.ngaybatdau.Location = new System.Drawing.Point(159, 195);
            this.ngaybatdau.Name = "ngaybatdau";
            this.ngaybatdau.Size = new System.Drawing.Size(198, 20);
            this.ngaybatdau.TabIndex = 45;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(70, 227);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 13);
            this.label15.TabIndex = 44;
            this.label15.Text = "Ngày kết thúc";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.hiểnThịToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 46;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hợpĐồngToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý";
            // 
            // hợpĐồngToolStripMenuItem
            // 
            this.hợpĐồngToolStripMenuItem.Name = "hợpĐồngToolStripMenuItem";
            this.hợpĐồngToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.hợpĐồngToolStripMenuItem.Text = "Phòng Trọ";
            this.hợpĐồngToolStripMenuItem.Click += new System.EventHandler(this.hợpĐồngToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tổngTiềnToolStripMenuItem,
            this.ngườiĐangThuêPhòngToolStripMenuItem});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống Kê";
            // 
            // tổngTiềnToolStripMenuItem
            // 
            this.tổngTiềnToolStripMenuItem.Name = "tổngTiềnToolStripMenuItem";
            this.tổngTiềnToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.tổngTiềnToolStripMenuItem.Text = "Tổng tiền Phòng";
            this.tổngTiềnToolStripMenuItem.Click += new System.EventHandler(this.tổngTiềnToolStripMenuItem_Click);
            // 
            // hiểnThịToolStripMenuItem
            // 
            this.hiểnThịToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.phòngToolStripMenuItem,
            this.HopDongToolStripMenuItem,
            this.tổngQuátToolStripMenuItem});
            this.hiểnThịToolStripMenuItem.Name = "hiểnThịToolStripMenuItem";
            this.hiểnThịToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.hiểnThịToolStripMenuItem.Text = "Hiển thị";
            // 
            // phòngToolStripMenuItem
            // 
            this.phòngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đãChoThuêToolStripMenuItem,
            this.chưaChoThuêToolStripMenuItem,
            this.thôngTinPhòngToolStripMenuItem});
            this.phòngToolStripMenuItem.Name = "phòngToolStripMenuItem";
            this.phòngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.phòngToolStripMenuItem.Text = "Phòng ";
            // 
            // đãChoThuêToolStripMenuItem
            // 
            this.đãChoThuêToolStripMenuItem.Name = "đãChoThuêToolStripMenuItem";
            this.đãChoThuêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đãChoThuêToolStripMenuItem.Text = "Đã Cho Thuê";
            this.đãChoThuêToolStripMenuItem.Click += new System.EventHandler(this.đãChoThuêToolStripMenuItem_Click_1);
            // 
            // chưaChoThuêToolStripMenuItem
            // 
            this.chưaChoThuêToolStripMenuItem.Name = "chưaChoThuêToolStripMenuItem";
            this.chưaChoThuêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.chưaChoThuêToolStripMenuItem.Text = "Chưa Cho Thuê";
            this.chưaChoThuêToolStripMenuItem.Click += new System.EventHandler(this.chưaChoThuêToolStripMenuItem_Click_1);
            // 
            // thôngTinPhòngToolStripMenuItem
            // 
            this.thôngTinPhòngToolStripMenuItem.Name = "thôngTinPhòngToolStripMenuItem";
            this.thôngTinPhòngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.thôngTinPhòngToolStripMenuItem.Text = "Thông Tin Phòng";
            this.thôngTinPhòngToolStripMenuItem.Click += new System.EventHandler(this.thôngTinPhòngToolStripMenuItem_Click);
            // 
            // HopDongToolStripMenuItem
            // 
            this.HopDongToolStripMenuItem.Name = "HopDongToolStripMenuItem";
            this.HopDongToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.HopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.HopDongToolStripMenuItem.Click += new System.EventHandler(this.ngườiThuêToolStripMenuItem_Click);
            // 
            // tổngQuátToolStripMenuItem
            // 
            this.tổngQuátToolStripMenuItem.Name = "tổngQuátToolStripMenuItem";
            this.tổngQuátToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tổngQuátToolStripMenuItem.Text = "Tổng Quát";
            this.tổngQuátToolStripMenuItem.Click += new System.EventHandler(this.tổngQuátToolStripMenuItem_Click);
            // 
            // ngườiĐangThuêPhòngToolStripMenuItem
            // 
            this.ngườiĐangThuêPhòngToolStripMenuItem.Name = "ngườiĐangThuêPhòngToolStripMenuItem";
            this.ngườiĐangThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.ngườiĐangThuêPhòngToolStripMenuItem.Text = "Người Đang Thuê Phòng";
            this.ngườiĐangThuêPhòngToolStripMenuItem.Click += new System.EventHandler(this.ngườiĐangThuêPhòngToolStripMenuItem_Click);
            // 
            // hopdong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 580);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.ngaybatdau);
            this.Controls.Add(this.ngayketthuc);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.mahopdong);
            this.Controls.Add(this.cancuocongdan);
            this.Controls.Add(this.hovaten);
            this.Controls.Add(this.sodienthoai);
            this.Controls.Add(this.sophong);
            this.Controls.Add(this.sotiencoc);
            this.Controls.Add(this.butredo);
            this.Controls.Add(this.butundo);
            this.Controls.Add(this.butload);
            this.Controls.Add(this.butxoa);
            this.Controls.Add(this.butsua);
            this.Controls.Add(this.butthem);
            this.Controls.Add(this.datagridviewhopdong);
            this.Name = "hopdong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hợp Đồng";
            this.Load += new System.EventHandler(this.hopdong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewhopdong)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView datagridviewphongtro;
        private System.Windows.Forms.Button butadd;
        private System.Windows.Forms.Button butalter;
        private System.Windows.Forms.Button butdelete;
        private System.Windows.Forms.Button butreload;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox textienmang;
        private System.Windows.Forms.TextBox textiennuoc;
        private System.Windows.Forms.TextBox textiendien;
        private System.Windows.Forms.TextBox texgiathue;
        private System.Windows.Forms.TextBox texsophong;
        private System.Windows.Forms.TextBox texdientich;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox textrangthai;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox mahopdong;
        private System.Windows.Forms.TextBox cancuocongdan;
        private System.Windows.Forms.TextBox hovaten;
        private System.Windows.Forms.TextBox sodienthoai;
        private System.Windows.Forms.TextBox sophong;
        private System.Windows.Forms.TextBox sotiencoc;
        private System.Windows.Forms.Button butload;
        private System.Windows.Forms.Button butxoa;
        private System.Windows.Forms.Button butsua;
        private System.Windows.Forms.Button butthem;
        private System.Windows.Forms.DataGridView datagridviewhopdong;
        private System.Windows.Forms.Button butundo;
        private System.Windows.Forms.Button butredo;
        private System.Windows.Forms.DateTimePicker ngayketthuc;
        private System.Windows.Forms.DateTimePicker ngaybatdau;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hợpĐồngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngTiềnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hiểnThịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đãChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chưaChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngQuátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ngườiĐangThuêPhòngToolStripMenuItem;
    }
}