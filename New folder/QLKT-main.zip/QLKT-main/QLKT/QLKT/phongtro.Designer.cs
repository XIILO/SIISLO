﻿namespace QLKT
{
    partial class phongtro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.datagridviewphongtro = new System.Windows.Forms.DataGridView();
            this.butadd = new System.Windows.Forms.Button();
            this.butalter = new System.Windows.Forms.Button();
            this.butdelete = new System.Windows.Forms.Button();
            this.butreload = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textienmang = new System.Windows.Forms.TextBox();
            this.textiennuoc = new System.Windows.Forms.TextBox();
            this.textiendien = new System.Windows.Forms.TextBox();
            this.texgiathue = new System.Windows.Forms.TextBox();
            this.texsophong = new System.Windows.Forms.TextBox();
            this.texdientich = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textrangthai = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hợpĐồngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngTiềnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hiểnThịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đãChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chưaChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngQuátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ngườiĐangThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewphongtro)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // datagridviewphongtro
            // 
            this.datagridviewphongtro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewphongtro.Location = new System.Drawing.Point(12, 254);
            this.datagridviewphongtro.Name = "datagridviewphongtro";
            this.datagridviewphongtro.Size = new System.Drawing.Size(776, 224);
            this.datagridviewphongtro.TabIndex = 0;
            this.datagridviewphongtro.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridviewphongtro_CellContentClick_1);
            // 
            // butadd
            // 
            this.butadd.Location = new System.Drawing.Point(692, 503);
            this.butadd.Name = "butadd";
            this.butadd.Size = new System.Drawing.Size(96, 60);
            this.butadd.TabIndex = 1;
            this.butadd.Text = "Add";
            this.butadd.UseVisualStyleBackColor = true;
            this.butadd.Click += new System.EventHandler(this.butadd_Click);
            // 
            // butalter
            // 
            this.butalter.Location = new System.Drawing.Point(590, 503);
            this.butalter.Name = "butalter";
            this.butalter.Size = new System.Drawing.Size(96, 60);
            this.butalter.TabIndex = 1;
            this.butalter.Text = "Alter";
            this.butalter.UseVisualStyleBackColor = true;
            this.butalter.Click += new System.EventHandler(this.butalter_Click);
            // 
            // butdelete
            // 
            this.butdelete.Location = new System.Drawing.Point(488, 503);
            this.butdelete.Name = "butdelete";
            this.butdelete.Size = new System.Drawing.Size(96, 60);
            this.butdelete.TabIndex = 1;
            this.butdelete.Text = "Delete";
            this.butdelete.UseVisualStyleBackColor = true;
            this.butdelete.Click += new System.EventHandler(this.butdelete_Click);
            // 
            // butreload
            // 
            this.butreload.Location = new System.Drawing.Point(692, 181);
            this.butreload.Name = "butreload";
            this.butreload.Size = new System.Drawing.Size(96, 60);
            this.butreload.TabIndex = 1;
            this.butreload.Text = "Reload";
            this.butreload.UseVisualStyleBackColor = true;
            this.butreload.Click += new System.EventHandler(this.butreload_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textienmang
            // 
            this.textienmang.Location = new System.Drawing.Point(150, 181);
            this.textienmang.Name = "textienmang";
            this.textienmang.Size = new System.Drawing.Size(198, 20);
            this.textienmang.TabIndex = 4;
            // 
            // textiennuoc
            // 
            this.textiennuoc.Location = new System.Drawing.Point(150, 155);
            this.textiennuoc.Name = "textiennuoc";
            this.textiennuoc.Size = new System.Drawing.Size(198, 20);
            this.textiennuoc.TabIndex = 4;
            // 
            // textiendien
            // 
            this.textiendien.Location = new System.Drawing.Point(150, 129);
            this.textiendien.Name = "textiendien";
            this.textiendien.Size = new System.Drawing.Size(198, 20);
            this.textiendien.TabIndex = 4;
            // 
            // texgiathue
            // 
            this.texgiathue.Location = new System.Drawing.Point(150, 77);
            this.texgiathue.Name = "texgiathue";
            this.texgiathue.Size = new System.Drawing.Size(198, 20);
            this.texgiathue.TabIndex = 4;
            // 
            // texsophong
            // 
            this.texsophong.Location = new System.Drawing.Point(150, 51);
            this.texsophong.Name = "texsophong";
            this.texsophong.Size = new System.Drawing.Size(198, 20);
            this.texsophong.TabIndex = 4;
            // 
            // texdientich
            // 
            this.texdientich.Location = new System.Drawing.Point(150, 103);
            this.texdientich.Name = "texdientich";
            this.texdientich.Size = new System.Drawing.Size(198, 20);
            this.texdientich.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Số phòng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Giá thuê";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Diện tích";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tiền điện";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Tiền nước";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Tiền mạng";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Trạng thái";
            // 
            // textrangthai
            // 
            this.textrangthai.FormattingEnabled = true;
            this.textrangthai.Items.AddRange(new object[] {
            "Đã cho thuê",
            "Chưa cho thuê"});
            this.textrangthai.Location = new System.Drawing.Point(150, 207);
            this.textrangthai.Name = "textrangthai";
            this.textrangthai.Size = new System.Drawing.Size(198, 21);
            this.textrangthai.TabIndex = 5;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(252, 503);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(96, 60);
            this.button6.TabIndex = 30;
            this.button6.Text = "Redo";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(150, 503);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(96, 60);
            this.button5.TabIndex = 31;
            this.button5.Text = "Undo";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.hiểnThịToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 32;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hợpĐồngToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý";
            // 
            // hợpĐồngToolStripMenuItem
            // 
            this.hợpĐồngToolStripMenuItem.Name = "hợpĐồngToolStripMenuItem";
            this.hợpĐồngToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.hợpĐồngToolStripMenuItem.Text = "Hợp Đồng";
            this.hợpĐồngToolStripMenuItem.Click += new System.EventHandler(this.hợpĐồngToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tổngTiềnToolStripMenuItem,
            this.ngườiĐangThuêPhòngToolStripMenuItem});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống Kê";
            // 
            // tổngTiềnToolStripMenuItem
            // 
            this.tổngTiềnToolStripMenuItem.Name = "tổngTiềnToolStripMenuItem";
            this.tổngTiềnToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.tổngTiềnToolStripMenuItem.Text = "Tổng tiền Phòng";
            this.tổngTiềnToolStripMenuItem.Click += new System.EventHandler(this.tổngTiềnToolStripMenuItem_Click);
            // 
            // hiểnThịToolStripMenuItem
            // 
            this.hiểnThịToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HopDongToolStripMenuItem,
            this.phòngToolStripMenuItem,
            this.tổngQuátToolStripMenuItem});
            this.hiểnThịToolStripMenuItem.Name = "hiểnThịToolStripMenuItem";
            this.hiểnThịToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.hiểnThịToolStripMenuItem.Text = "Hiển thị";
            // 
            // HopDongToolStripMenuItem
            // 
            this.HopDongToolStripMenuItem.Name = "HopDongToolStripMenuItem";
            this.HopDongToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.HopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.HopDongToolStripMenuItem.Click += new System.EventHandler(this.HopDongToolStripMenuItem_Click);
            // 
            // phòngToolStripMenuItem
            // 
            this.phòngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đãChoThuêToolStripMenuItem,
            this.chưaChoThuêToolStripMenuItem,
            this.thôngTinPhòngToolStripMenuItem});
            this.phòngToolStripMenuItem.Name = "phòngToolStripMenuItem";
            this.phòngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.phòngToolStripMenuItem.Text = "Phòng ";
            // 
            // đãChoThuêToolStripMenuItem
            // 
            this.đãChoThuêToolStripMenuItem.Name = "đãChoThuêToolStripMenuItem";
            this.đãChoThuêToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.đãChoThuêToolStripMenuItem.Text = "Đã Cho Thuê";
            this.đãChoThuêToolStripMenuItem.Click += new System.EventHandler(this.đãChoThuêToolStripMenuItem_Click);
            // 
            // chưaChoThuêToolStripMenuItem
            // 
            this.chưaChoThuêToolStripMenuItem.Name = "chưaChoThuêToolStripMenuItem";
            this.chưaChoThuêToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.chưaChoThuêToolStripMenuItem.Text = "Chưa Cho Thuê";
            this.chưaChoThuêToolStripMenuItem.Click += new System.EventHandler(this.chưaChoThuêToolStripMenuItem_Click);
            // 
            // thôngTinPhòngToolStripMenuItem
            // 
            this.thôngTinPhòngToolStripMenuItem.Name = "thôngTinPhòngToolStripMenuItem";
            this.thôngTinPhòngToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.thôngTinPhòngToolStripMenuItem.Text = "Thông Tin Phòng";
            this.thôngTinPhòngToolStripMenuItem.Click += new System.EventHandler(this.thôngTinPhòngToolStripMenuItem_Click);
            // 
            // tổngQuátToolStripMenuItem
            // 
            this.tổngQuátToolStripMenuItem.Name = "tổngQuátToolStripMenuItem";
            this.tổngQuátToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tổngQuátToolStripMenuItem.Text = "Tổng Quát";
            this.tổngQuátToolStripMenuItem.Click += new System.EventHandler(this.tổngQuátToolStripMenuItem_Click);
            // 
            // ngườiĐangThuêPhòngToolStripMenuItem
            // 
            this.ngườiĐangThuêPhòngToolStripMenuItem.Name = "ngườiĐangThuêPhòngToolStripMenuItem";
            this.ngườiĐangThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.ngườiĐangThuêPhòngToolStripMenuItem.Text = "Người Đang Thuê Phòng";
            this.ngườiĐangThuêPhòngToolStripMenuItem.Click += new System.EventHandler(this.ngườiĐangThuêPhòngToolStripMenuItem_Click);
            // 
            // phongtro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 580);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textrangthai);
            this.Controls.Add(this.texsophong);
            this.Controls.Add(this.texgiathue);
            this.Controls.Add(this.texdientich);
            this.Controls.Add(this.textiendien);
            this.Controls.Add(this.textiennuoc);
            this.Controls.Add(this.textienmang);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.butreload);
            this.Controls.Add(this.butdelete);
            this.Controls.Add(this.butalter);
            this.Controls.Add(this.butadd);
            this.Controls.Add(this.datagridviewphongtro);
            this.Name = "phongtro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phòng trọ";
            this.Load += new System.EventHandler(this.phongtro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewphongtro)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datagridviewphongtro;
        private System.Windows.Forms.Button butadd;
        private System.Windows.Forms.Button butalter;
        private System.Windows.Forms.Button butdelete;
        private System.Windows.Forms.Button butreload;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox textienmang;
        private System.Windows.Forms.TextBox textiennuoc;
        private System.Windows.Forms.TextBox textiendien;
        private System.Windows.Forms.TextBox texgiathue;
        private System.Windows.Forms.TextBox texsophong;
        private System.Windows.Forms.TextBox texdientich;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox textrangthai;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hợpĐồngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngTiềnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hiểnThịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đãChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chưaChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngQuátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ngườiĐangThuêPhòngToolStripMenuItem;
    }
}