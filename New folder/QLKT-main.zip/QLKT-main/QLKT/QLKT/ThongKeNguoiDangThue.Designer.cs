﻿namespace QLKT
{
    partial class ThongKeNguoiDangThue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hợpĐồngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hợpĐồngToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ngườiĐangThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hiểnThịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đãChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chưaChoThuêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngQuátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvtk = new System.Windows.Forms.DataGridView();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thốngKêToolStripMenuItem,
            this.hiểnThịToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(933, 24);
            this.menuStrip2.TabIndex = 48;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hợpĐồngToolStripMenuItem,
            this.hợpĐồngToolStripMenuItem1});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý";
            // 
            // hợpĐồngToolStripMenuItem
            // 
            this.hợpĐồngToolStripMenuItem.Name = "hợpĐồngToolStripMenuItem";
            this.hợpĐồngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hợpĐồngToolStripMenuItem.Text = "Phòng Trọ";
            this.hợpĐồngToolStripMenuItem.Click += new System.EventHandler(this.hợpĐồngToolStripMenuItem_Click);
            // 
            // hợpĐồngToolStripMenuItem1
            // 
            this.hợpĐồngToolStripMenuItem1.Name = "hợpĐồngToolStripMenuItem1";
            this.hợpĐồngToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.hợpĐồngToolStripMenuItem1.Text = "Hợp Đồng";
            this.hợpĐồngToolStripMenuItem1.Click += new System.EventHandler(this.hợpĐồngToolStripMenuItem1_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ngườiĐangThuêToolStripMenuItem});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống Kê";
            // 
            // ngườiĐangThuêToolStripMenuItem
            // 
            this.ngườiĐangThuêToolStripMenuItem.Name = "ngườiĐangThuêToolStripMenuItem";
            this.ngườiĐangThuêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ngườiĐangThuêToolStripMenuItem.Text = "Tiền Phòng Trọ";
            this.ngườiĐangThuêToolStripMenuItem.Click += new System.EventHandler(this.ngườiĐangThuêToolStripMenuItem_Click);
            // 
            // hiểnThịToolStripMenuItem
            // 
            this.hiểnThịToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.phòngToolStripMenuItem,
            this.HopDongToolStripMenuItem,
            this.tổngQuátToolStripMenuItem});
            this.hiểnThịToolStripMenuItem.Name = "hiểnThịToolStripMenuItem";
            this.hiểnThịToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.hiểnThịToolStripMenuItem.Text = "Hiển thị";
            // 
            // phòngToolStripMenuItem
            // 
            this.phòngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đãChoThuêToolStripMenuItem,
            this.chưaChoThuêToolStripMenuItem,
            this.thôngTinPhòngToolStripMenuItem});
            this.phòngToolStripMenuItem.Name = "phòngToolStripMenuItem";
            this.phòngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.phòngToolStripMenuItem.Text = "Phòng ";
            // 
            // đãChoThuêToolStripMenuItem
            // 
            this.đãChoThuêToolStripMenuItem.Name = "đãChoThuêToolStripMenuItem";
            this.đãChoThuêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đãChoThuêToolStripMenuItem.Text = "Đã Cho Thuê";
            this.đãChoThuêToolStripMenuItem.Click += new System.EventHandler(this.đãChoThuêToolStripMenuItem_Click);
            // 
            // chưaChoThuêToolStripMenuItem
            // 
            this.chưaChoThuêToolStripMenuItem.Name = "chưaChoThuêToolStripMenuItem";
            this.chưaChoThuêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.chưaChoThuêToolStripMenuItem.Text = "Chưa Cho Thuê";
            this.chưaChoThuêToolStripMenuItem.Click += new System.EventHandler(this.chưaChoThuêToolStripMenuItem_Click);
            // 
            // thôngTinPhòngToolStripMenuItem
            // 
            this.thôngTinPhòngToolStripMenuItem.Name = "thôngTinPhòngToolStripMenuItem";
            this.thôngTinPhòngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.thôngTinPhòngToolStripMenuItem.Text = "Thông Tin Phòng";
            this.thôngTinPhòngToolStripMenuItem.Click += new System.EventHandler(this.thôngTinPhòngToolStripMenuItem_Click);
            // 
            // HopDongToolStripMenuItem
            // 
            this.HopDongToolStripMenuItem.Name = "HopDongToolStripMenuItem";
            this.HopDongToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.HopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.HopDongToolStripMenuItem.Click += new System.EventHandler(this.HopDongToolStripMenuItem_Click);
            // 
            // tổngQuátToolStripMenuItem
            // 
            this.tổngQuátToolStripMenuItem.Name = "tổngQuátToolStripMenuItem";
            this.tổngQuátToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tổngQuátToolStripMenuItem.Text = "Tổng Quát";
            this.tổngQuátToolStripMenuItem.Click += new System.EventHandler(this.tổngQuátToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(275, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 22);
            this.label1.TabIndex = 49;
            this.label1.Text = "THỐNG KÊ NGƯỜI ĐANG THUÊ PHÒNG";
            // 
            // dgvtk
            // 
            this.dgvtk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvtk.Location = new System.Drawing.Point(12, 92);
            this.dgvtk.Name = "dgvtk";
            this.dgvtk.Size = new System.Drawing.Size(909, 184);
            this.dgvtk.TabIndex = 50;
            // 
            // ThongKeNguoiDangThue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 309);
            this.Controls.Add(this.dgvtk);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip2);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ThongKeNguoiDangThue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThongKeNguoiDangThue";
            this.Load += new System.EventHandler(this.ThongKeNguoiDangThue_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hợpĐồngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hợpĐồngToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ngườiĐangThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hiểnThịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đãChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chưaChoThuêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngQuátToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvtk;
    }
}